mode2 <- function(weights) {
  tabled <- table(weights)
  sortedtable <-sort(tabled);
  tlen<- length(sortedtable);
  djan<-as.data.frame(sortedtable)
  if(djan[tlen,2] == djan[tlen-1,2])
  {
    return("NA")
  }
  else
  {
    return(as.character(djan[tlen,1]));
  }
}
#how to find the actual mode (like mean/median/mode)
#in this data set's case, it sorts the called table by frequency
#and then makes it a data frame
#it then compares the last 2 numbers. If the frequency number matches, there is no mode and calls NA
#if the frequency numbers don't match, then there is a mode and prints the value

