dweight <- read.table('dweight.txt',header = TRUE)
maxover<- max(dweight[,2:13])
# highest weight value overall
minover<- min(dweight[,2:13])
#lowest weight value overall
feb<-dweight$Feb
mar<-dweight$Mar
apr<-dweight$Apr
may<-dweight$May
jun<-dweight$Jun
jul<-dweight$Jul
aug<-dweight$Aug
sep<-dweight$Sep
oct<-dweight$Oct
nov<-dweight$Oct
dec<-dweight$Dec
#easier way to call all the values in a given month
Bentley<-as.numeric(dweight[1,2:13])
Chichi<-as.numeric(dweight[2,2:13])
Cooper<-as.numeric(dweight[3,2:13])
Dodger<-as.numeric(dweight[4,2:13])
Lucy<-as.numeric(dweight[5,2:13])
Mercy<-as.numeric(dweight[6,2:13])
Saesay<-as.numeric(dweight[7,2:13])
Sheila<-as.numeric(dweight[8,2:13])
#easier way to call all the values for a given dog
